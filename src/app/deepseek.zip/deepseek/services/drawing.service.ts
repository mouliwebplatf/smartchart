// drawing.service.ts

import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { v4 as uuidv4 } from 'uuid';
import { DrawingLine } from '../models/drawing.model';

@Injectable({ providedIn: 'root' })
export class DrawingService {
  private adminLines = new Map<number, DrawingLine[]>();  // Reference lines (answer key)
  private userLines = new Map<number, DrawingLine[]>();   // User drawn lines
  private matchedAdminLines = new Map<number, Set<string>>(); // Track matched/hidden admin lines

  constructor() {
    this.loadFromLocalStorage();
  }

  // ═══════════════════════════ ADMIN LINES (Reference/Answer Key) ═══════════════════════════

  /**
   * Get all admin reference lines for a test
   */
  getAdminLines(testId: number): Observable<DrawingLine[]> {
    return of([...(this.adminLines.get(testId) ?? [])]);
  }

  /**
   * Add a single admin line (during drawing)
   */
  addAdminLine(testId: number, line: DrawingLine): Observable<DrawingLine> {
    const lines = this.adminLines.get(testId) ?? [];
    if (!lines.find(l => l.id === line.id)) {
      lines.push({ ...line, type: 'admin' });
    }
    this.adminLines.set(testId, lines);
    return of({ ...line });
  }

  /**
   * Save all admin lines as reference (called when admin clicks Save)
   * This resets any previous matches
   */
  saveAdminLines(testId: number, lines: DrawingLine[]): Observable<DrawingLine[]> {
    this.adminLines.set(testId, lines.map(l => ({ ...l, type: 'admin' })));
    // Reset matched progress when new admin lines are saved
    this.matchedAdminLines.set(testId, new Set());
    this.persist();
    console.log(`[DrawingService] Saved ${lines.length} reference lines for test ${testId}`);
    return of([...lines]);
  }

  /**
   * Update an existing admin line
   */
  updateAdminLine(testId: number, lineId: string, updates: Partial<DrawingLine>): Observable<DrawingLine[]> {
    const lines = this.adminLines.get(testId) ?? [];
    const idx = lines.findIndex(l => l.id === lineId);
    if (idx !== -1) {
      lines[idx] = { ...lines[idx], ...updates, updatedAt: new Date() };
      this.adminLines.set(testId, lines);
    }
    return of([...lines]);
  }

  /**
   * Delete a single admin line
   */
  deleteAdminLine(testId: number, lineId: string): Observable<DrawingLine[]> {
    const filtered = (this.adminLines.get(testId) ?? []).filter(l => l.id !== lineId);
    this.adminLines.set(testId, filtered);
    return of([...filtered]);
  }

  /**
   * Clear all admin lines for a test
   */
  clearAdminLines(testId: number): Observable<void> {
    this.adminLines.set(testId, []);
    this.matchedAdminLines.set(testId, new Set());
    this.persist();
    console.log(`[DrawingService] Cleared all admin lines for test ${testId}`);
    return of(void 0);
  }

  /**
   * Clear admin lines from memory only (for admin drawing session)
   * Does NOT affect saved reference lines
   */
  clearAdminLinesInMemoryOnly(testId: number): void {
    this.adminLines.set(testId, []);
    console.log(`[DrawingService] Cleared admin lines from memory for test ${testId}`);
  }

  // ═══════════════════════════ USER LINES (Student Drawings) ════════════════════════════

  /**
   * Get all user drawn lines for a test
   */
  getUserLines(testId: number): Observable<DrawingLine[]> {
    return of([...(this.userLines.get(testId) ?? [])]);
  }

  /**
   * Save a user drawn line (after validation)
   */
  saveUserLine(testId: number, line: DrawingLine): Observable<DrawingLine> {
    const lines = this.userLines.get(testId) ?? [];
    if (!lines.find(l => l.id === line.id)) {
      lines.push({ ...line, type: 'user' });
    }
    this.userLines.set(testId, lines);
    this.persist();
    console.log(`[DrawingService] Saved user line for test ${testId}`);
    return of({ ...line });
  }

  /**
   * Update an existing user line
   */
  updateUserLine(testId: number, lineId: string, updates: Partial<DrawingLine>): Observable<DrawingLine[]> {
    const lines = this.userLines.get(testId) ?? [];
    const idx = lines.findIndex(l => l.id === lineId);
    if (idx !== -1) {
      lines[idx] = { ...lines[idx], ...updates, updatedAt: new Date() };
      this.userLines.set(testId, lines);
      this.persist();
    }
    return of([...lines]);
  }

  /**
   * Delete a user line
   */
  deleteUserLine(testId: number, lineId: string): Observable<DrawingLine[]> {
    const filtered = (this.userLines.get(testId) ?? []).filter(l => l.id !== lineId);
    this.userLines.set(testId, filtered);
    this.persist();
    return of([...filtered]);
  }

  /**
   * Clear all user lines for a test
   */
  clearAllUserLines(testId: number): Observable<void> {
    this.userLines.set(testId, []);
    this.persist();
    console.log(`[DrawingService] Cleared all user lines for test ${testId}`);
    return of(void 0);
  }

  /**
   * Reset user lines (alias for clearAllUserLines)
   */
  resetUserLines(testId: number): Observable<void> {
    return this.clearAllUserLines(testId);
  }

  /**
   * Delete all user lines (alias for clearAllUserLines)
   */
  deleteAllUserLines(testId: number): Observable<void> {
    return this.clearAllUserLines(testId);
  }

  // ═══════════════════════════ MATCHED LINES TRACKING ═══════════════════════════

  /**
   * Get all matched (hidden) admin line IDs for a test
   */
  getMatchedAdminLines(testId: number): Set<string> {
    return this.matchedAdminLines.get(testId) ?? new Set();
  }

  /**
   * Get only admin lines that are NOT yet matched (visible to users)
   */
  getUnmatchedAdminLines(testId: number): DrawingLine[] {
    const allAdminLines = this.adminLines.get(testId) ?? [];
    const matchedIds = this.matchedAdminLines.get(testId) ?? new Set();
    return allAdminLines.filter(line => !matchedIds.has(line.id));
  }

  /**
   * Get hidden/matched admin line IDs (alias)
   */
  getHiddenAdminLineIds(testId: number): Set<string> {
    return this.matchedAdminLines.get(testId) ?? new Set();
  }

  /**
   * Mark an admin line as matched (hide it from user)
   */
  markAdminLineAsMatched(testId: number, adminLineId: string): void {
    const matched = this.matchedAdminLines.get(testId) ?? new Set();
    matched.add(adminLineId);
    this.matchedAdminLines.set(testId, matched);
    this.persist();
    console.log(`[DrawingService] Admin line ${adminLineId.substring(0, 8)} matched and hidden for test ${testId}`);
  }

  /**
   * Clear all matched lines (reset progress)
   */
  clearMatchedLines(testId: number): void {
    this.matchedAdminLines.set(testId, new Set());
    this.persist();
    console.log(`[DrawingService] Cleared all matched lines for test ${testId}`);
  }

  /**
   * Check if all admin lines have been matched (test complete)
   */
  isTestComplete(testId: number): boolean {
    const allAdminLines = this.adminLines.get(testId) ?? [];
    const matchedIds = this.matchedAdminLines.get(testId) ?? new Set();
    return allAdminLines.length > 0 && allAdminLines.length === matchedIds.size;
  }

  /**
   * Get test progress percentage for user
   */
  getTestProgress(testId: number): number {
    const allAdminLines = this.adminLines.get(testId) ?? [];
    const matchedIds = this.matchedAdminLines.get(testId) ?? new Set();
    if (allAdminLines.length === 0) return 0;
    return (matchedIds.size / allAdminLines.length) * 100;
  }

  /**
   * Get remaining lines count for user
   */
  getRemainingLinesCount(testId: number): number {
    const allAdminLines = this.adminLines.get(testId) ?? [];
    const matchedIds = this.matchedAdminLines.get(testId) ?? new Set();
    return allAdminLines.length - matchedIds.size;
  }

  // ═══════════════════════════ VALIDATION LOGIC ═══════════════════════════

  /**
   * Validate a user line against unmached admin reference lines
   */
  validateUserLine(testId: number, userLine: DrawingLine): ValidationResult {
    // Get only admin lines that haven't been matched yet
    const availableAdminLines = this.getUnmatchedAdminLines(testId);
    
    console.log(`[DrawingService] Validating line for test ${testId}, available admin lines: ${availableAdminLines.length}`);
    
    if (availableAdminLines.length === 0) {
      const isComplete = this.isTestComplete(testId);
      if (isComplete) {
        return {
          isValid: true,
          score: 0,
          isWithinTolerance: true,
          remainingCount: 0,
          message: '🎉 Congratulations! You have matched all lines! Test complete! 🎉'
        };
      }
      return {
        isValid: true,
        score: 0,
        isWithinTolerance: true,
        remainingCount: 0,
        message: 'No reference lines available. Admin needs to add reference lines.'
      };
    }

    // Find the best matching admin line among available ones
    let bestMatch: DrawingLine | null = null;
    let bestScore = Infinity;

    for (const adminLine of availableAdminLines) {
      const score = this.calculateLineSimilarity(userLine, adminLine);
      console.log(`[DrawingService] Score for admin line ${adminLine.id.substring(0, 8)}: ${score.toFixed(4)}`);
      if (score < bestScore) {
        bestScore = score;
        bestMatch = adminLine;
      }
    }

    // Threshold for acceptance (0.02 = 2% difference)
    const isValid = bestScore < 0.02;
    
    if (isValid && bestMatch) {
      // Mark this admin line as matched (will be hidden)
      this.markAdminLineAsMatched(testId, bestMatch.id);
      
      const remainingCount = this.getRemainingLinesCount(testId);
      
      return {
        isValid: true,
        score: bestScore,
        isWithinTolerance: true,
        correctLine: bestMatch,
        remainingCount: remainingCount,
        message: remainingCount === 0 
          ? '🎉 Perfect! You have matched all lines! Test complete! 🎉' 
          : `✓ Correct match! ${remainingCount} line(s) remaining to match.`
      };
    }

    return {
      isValid: false,
      score: bestScore,
      isWithinTolerance: false,
      correctLine: bestMatch ?? undefined,
      remainingCount: availableAdminLines.length,
      message: '✗ Line does not match reference. Check slope, position, or price levels and try again.'
    };
  }

  /**
   * Calculate similarity between user line and admin reference line
   * Returns a score where lower is better (0 = perfect match)
   */
  private calculateLineSimilarity(user: DrawingLine, admin: DrawingLine): number {
    const toleranceSec = 86400; // 1 day tolerance for endpoints (24 hours * 3600 seconds)

    const userStart = user.startTime;
    const userEnd = user.endTime;
    const adminStart = admin.startTime;
    const adminEnd = admin.endTime;

    // 1. Check endpoint proximity
    const startDiff = Math.abs(userStart - adminStart);
    const endDiff = Math.abs(userEnd - adminEnd);

    if (startDiff > toleranceSec || endDiff > toleranceSec) {
      return 2.0; // Endpoints too far - invalid
    }

    // 2. Calculate overlap region for comparison
    const overlapStart = Math.max(userStart, adminStart);
    const overlapEnd = Math.min(userEnd, adminEnd);
    
    if (overlapEnd <= overlapStart) return 2.0;

    // 3. Calculate slopes
    const slopeUser = (user.endPrice - user.startPrice) / (user.endTime - user.startTime);
    const slopeAdmin = (admin.endPrice - admin.startPrice) / (admin.endTime - admin.startTime);
    
    const interceptUser = user.startPrice - slopeUser * user.startTime;
    const interceptAdmin = admin.startPrice - slopeAdmin * admin.startTime;

    // 4. Price tolerance (3% of price level)
    const priceLevel = Math.max(Math.abs(admin.startPrice), Math.abs(admin.endPrice), 1);
    const tolerancePrice = priceLevel * 0.03;

    // 5. Compare multiple points across the overlap
    let totalDiff = 0;
    const steps = 5; // Compare at 5 points along the line
    
    for (let i = 0; i <= steps; i++) {
      const t = overlapStart + (overlapEnd - overlapStart) * (i / steps);
      const priceUser = slopeUser * t + interceptUser;
      const priceAdmin = slopeAdmin * t + interceptAdmin;
      totalDiff += Math.abs(priceUser - priceAdmin) / tolerancePrice;
    }

    const averageDiff = totalDiff / (steps + 1);
    
    // 6. Add slope difference penalty
    const slopeDiff = Math.abs(slopeUser - slopeAdmin) / (Math.abs(slopeAdmin) + 0.0001);
    const finalScore = averageDiff * 0.7 + Math.min(slopeDiff, 1) * 0.3;
    
    return finalScore;
  }

  /**
   * Find admin line that contains user's time range (for time-based matching)
   */
  findAdminLineContainingTimeRange(testId: number, userLine: DrawingLine): DrawingLine | null {
    const adminLines = this.adminLines.get(testId) ?? [];
    const toleranceSec = 2 * 86400; // 2 days tolerance on each side

    for (const admin of adminLines) {
      // Expand admin range by tolerance
      const adminStart = admin.startTime - toleranceSec;
      const adminEnd = admin.endTime + toleranceSec;
      const userStart = userLine.startTime;
      const userEnd = userLine.endTime;

      // Check for any overlap (intersection)
      if (userStart <= adminEnd && userEnd >= adminStart) {
        return admin; // first admin line that overlaps in time
      }
    }
    return null;
  }

  // ═══════════════════════════ SAVE ALL (Role-aware) ═══════════════════════════

  /**
   * Explicitly persist whatever is in memory right now
   * Admin → re-saves adminLines (correct answers)
   * User → re-saves userLines
   */
  saveAllLines(testId: number, role: 'admin' | 'user'): Observable<DrawingLine[]> {
    if (role === 'admin') {
      const lines = [...(this.adminLines.get(testId) ?? [])];
      this.adminLines.set(testId, lines);
      this.persist();
      console.log(`[DrawingService] Admin saved ${lines.length} reference lines for test ${testId}`);
      return of(lines);
    } else {
      const lines = [...(this.userLines.get(testId) ?? [])];
      this.userLines.set(testId, lines);
      this.persist();
      console.log(`[DrawingService] User saved ${lines.length} drawing lines for test ${testId}`);
      return of(lines);
    }
  }

  // ═══════════════════════════ DUPLICATE LINE ═══════════════════════════

  /**
   * Duplicate a line with offset for user practice
   */
  duplicateLine(
    testId: number,
    original: DrawingLine,
    offsetPrice: number,
    offsetTime: number
  ): Observable<DrawingLine> {
    const dup: DrawingLine = {
      ...original,
      id: uuidv4(),
      parentId: original.id,
      type: 'user',
      duplicateCount: (original.duplicateCount || 0) + 1,
      startTime: original.startTime + offsetTime,
      endTime: original.endTime + offsetTime,
      startPrice: original.startPrice + offsetPrice,
      endPrice: original.endPrice + offsetPrice,
      color: this.getDuplicateColor(original.duplicateCount || 0),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    const lines = this.userLines.get(testId) ?? [];
    lines.push(dup);
    this.userLines.set(testId, lines);
    this.persist();
    return of({ ...dup });
  }

  /**
   * Get color for duplicated line based on duplicate count
   */
  private getDuplicateColor(count: number): string {
    const colors = ['#FFA500', '#FF6B6B', '#4ECDC4', '#95E77E', '#FFD93D'];
    return colors[count % colors.length];
  }

  // ═══════════════════════════ RESET FUNCTIONS ═══════════════════════════

  /**
   * Reset test for user (clears user lines and matched progress)
   */
  resetTestForUser(testId: number): Observable<void> {
    this.userLines.set(testId, []);
    this.matchedAdminLines.set(testId, new Set());
    this.persist();
    console.log(`[DrawingService] Test ${testId} reset for user`);
    return of(void 0);
  }

  /**
   * Complete reset of all test data (admin lines, user lines, matches)
   */
  resetAllTestData(testId: number): Observable<void> {
    this.adminLines.set(testId, []);
    this.userLines.set(testId, []);
    this.matchedAdminLines.set(testId, new Set());
    this.persist();
    console.log(`[DrawingService] All data for test ${testId} has been reset`);
    return of(void 0);
  }

  // ═══════════════════════════ UTILITY METHODS ═══════════════════════════

  /**
   * Get all admin lines (including matched ones) - for debugging
   */
  getAllAdminLinesForDebug(testId: number): DrawingLine[] {
    return [...(this.adminLines.get(testId) ?? [])];
  }

  /**
   * Get statistics for a test
   */
  getTestStatistics(testId: number): Observable<{
    totalAdminLines: number;
    matchedLines: number;
    remainingLines: number;
    userLinesCount: number;
    progress: number;
    isComplete: boolean;
  }> {
    const totalAdminLines = this.adminLines.get(testId) ?? [];
    const matchedIds = this.matchedAdminLines.get(testId) ?? new Set();
    const userLinesList = this.userLines.get(testId) ?? [];
    
    const stats = {
      totalAdminLines: totalAdminLines.length,
      matchedLines: matchedIds.size,
      remainingLines: totalAdminLines.length - matchedIds.size,
      userLinesCount: userLinesList.length,
      progress: totalAdminLines.length > 0 ? (matchedIds.size / totalAdminLines.length) * 100 : 0,
      isComplete: totalAdminLines.length > 0 && totalAdminLines.length === matchedIds.size
    };
    
    return of(stats);
  }

  // ═══════════════════════════ PERSISTENCE ═══════════════════════════

  /**
   * Persist all data to localStorage
   */
  private persist(): void {
    try {
      const dataToStore = {
        adminLines: Array.from(this.adminLines.entries()),
        userLines: Array.from(this.userLines.entries()),
        matchedAdminLines: Array.from(this.matchedAdminLines.entries()).map(
          ([testId, set]) => [testId, Array.from(set)]
        ),
        version: '2.0',
        lastUpdated: new Date().toISOString()
      };
      localStorage.setItem('drawing_data', JSON.stringify(dataToStore));
      console.log('[DrawingService] Data persisted successfully');
    } catch (e) {
      console.warn('[DrawingService] Persist failed:', e);
    }
  }

  /**
   * Load all data from localStorage
   */
  private loadFromLocalStorage(): void {
    try {
      const raw = localStorage.getItem('drawing_data');
      if (!raw) {
        console.log('[DrawingService] No existing data found, starting fresh');
        return;
      }
      
      const parsed = JSON.parse(raw);
      
      // Restore admin lines
      if (parsed.adminLines) {
        this.adminLines = new Map(
          parsed.adminLines.map(([k, v]: [any, DrawingLine[]]) => [Number(k), v])
        );
      }
      
      // Restore user lines
      if (parsed.userLines) {
        this.userLines = new Map(
          parsed.userLines.map(([k, v]: [any, DrawingLine[]]) => [Number(k), v])
        );
      }
      
      // Restore matched admin lines
      if (parsed.matchedAdminLines) {
        this.matchedAdminLines = new Map(
          parsed.matchedAdminLines.map(([id, arr]: [number, string[]]) => [id, new Set(arr)])
        );
      }
      
      console.log('[DrawingService] Data loaded successfully');
      console.log(`[DrawingService] Loaded ${this.adminLines.size} test admin line sets`);
      console.log(`[DrawingService] Loaded ${this.userLines.size} test user line sets`);
    } catch (error) {
      console.error('[DrawingService] Failed to load data:', error);
      // Initialize empty maps on error
      this.adminLines = new Map();
      this.userLines = new Map();
      this.matchedAdminLines = new Map();
    }
  }

  /**
   * Clear all data from localStorage (for testing/reset)
   */
  clearAllData(): Observable<void> {
    this.adminLines.clear();
    this.userLines.clear();
    this.matchedAdminLines.clear();
    localStorage.removeItem('drawing_data');
    console.log('[DrawingService] All data cleared');
    return of(void 0);
  }
}

// Export the ValidationResult interface if not already defined elsewhere
export interface ValidationResult {
  isValid: boolean;
  score: number;
  isWithinTolerance: boolean;
  correctLine?: DrawingLine;
  remainingCount: number;
  message: string;
  matchedLineId?: string;
}