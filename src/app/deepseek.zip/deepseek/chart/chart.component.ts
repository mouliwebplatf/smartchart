import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { v4 as uuidv4 } from 'uuid';
import * as LightweightCharts from 'lightweight-charts';

import { DrawingService } from '../services/drawing.service';
import { AuthService } from '../services/auth.service';
import { DrawingLine, Point, ScreenPoint, ThemeMode } from '../models/drawing.model';
import { Subject, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { TestService } from '../services/test.service';

type ToolMode = 'trendline' | 'hline' | 'vline' | 'ray' | 'straightline' | 'select';

@Component({
  selector: 'app-chart',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss']
})
export class ChartComponent implements AfterViewInit, OnDestroy {
  private isMoveMode: boolean = false;
  private movingLineId: string | null = null;
  private movingLineOwner: 'user' | 'admin' | null = null;
  private movingLineSnapshot: DrawingLine | null = null;
  private movePreviewSeries: any = null;
  private dragLineSnapshot: DrawingLine | null = null;
  private updatingPreview: boolean = false;

  private isDuplicating: boolean = false;

  shiftHeld: boolean = false;
  totalAdminLines: number = 0;
  matchedCount: number = 0;
  testComplete: boolean = false;
  @ViewChild('chartContainer') chartContainer!: ElementRef<HTMLDivElement>;
  @ViewChild('handleCanvas') handleCanvas!: ElementRef<HTMLCanvasElement>;

  extendLeftValue: number = 0;
  extendRightValue: number = 0;
  showExtendControls: boolean = false;
  extendingLineId: string | null = null;

  public isExtendingLeftHandle: boolean = false;
  public isExtendingRightHandle: boolean = false;
  private extendingLineIdHandle: string | null = null;
  private handleCanvasContext: CanvasRenderingContext2D | null = null;
  private animationFrameId: number | null = null;
  private originalLineState: DrawingLine | null = null;
  lastSavedTime: Date | null = null;

  private destroy$ = new Subject<void>();
  private isResetting = false;

  testId: number = 0;
  testName: string = '';
  userRole: string | null = null;
  currentTheme: ThemeMode = 'dark';

  durationValue: number = 1;
  durationType: string = 'month';

  activeTool: ToolMode = 'select';
  isDrawing: boolean = false;
  private drawingStartPoint: Point | null = null;

  private previewSeries: any = null;
  private hasFirstPoint: boolean = false;

  userLines: DrawingLine[] = [];
  adminLines: DrawingLine[] = [];
  selectedLineId: string | null = null;
  selectedLineOwner: 'user' | 'admin' | null = null;

  private isDraggingLine: boolean = false;
  private draggedLineId: string | null = null;
  private dragStartPoint: { time: number; price: number } | null = null;
  private dragDistance: number = 0;
  private hoveredLineId: string | null = null;
  cursorIsOverInteractable: boolean = false;

  validationMessage: string = '';
  messageType: 'success' | 'error' | 'info' = 'info';

  private chart: any = null;
  private candlestickSeries: any = null;
  private lineSeriesMap: Map<string, any> = new Map();
  private chartData: any[] = [];
  private isFreshUserSession: boolean = true;

  private themes = {
    light: { background: '#ffffff', textColor: '#333333', gridColor: '#e0e0e0', borderColor: '#d1d1d1' },
    dark:  { background: '#1e222d', textColor: '#d1d4dc', gridColor: '#2a2e39', borderColor: '#2a2e39' }
  };

  private clickTimeout: any = null;
  private isDoubleClick: boolean = false;

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private drawingService: DrawingService,
    private testService: TestService
  ) {}

  ngAfterViewInit(): void {
    this.testId   = Number(this.route.snapshot.paramMap.get('id'));
    this.userRole = this.authService.getRole();
    this.testName = this.route.snapshot.queryParams['name'] || 'NIFTY 50';

    if (this.userRole !== 'admin' && this.isFreshUserSession) {
      this.drawingService.clearAllUserLines(this.testId).subscribe(() => {
        this.drawingService.clearMatchedLines(this.testId);
        this.userLines     = [];
        this.matchedCount  = 0;
        this.totalAdminLines = 0;
        this.testComplete  = false;
      });
    }

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        this.initChart().then(() => this.loadData());
      });
    });
  }

  ngOnDestroy(): void {
    if (this.chart) this.chart.remove();
    this.destroy$.next();
    this.destroy$.complete();
    window.removeEventListener('resize', this.handleResize);
    if (this.animationFrameId) cancelAnimationFrame(this.animationFrameId);
    if (this.clickTimeout) clearTimeout(this.clickTimeout);
  }

  // ==================== THEME ====================
  toggleTheme(): void {
    this.currentTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
    this.applyTheme();
  }

  private applyTheme(): void {
    const t = this.themes[this.currentTheme];
    if (!this.chart) return;
    this.chart.applyOptions({
      layout:         { background: { color: t.background }, textColor: t.textColor },
      grid:           { vertLines: { color: t.gridColor }, horzLines: { color: t.gridColor } },
      timeScale:      { borderColor: t.borderColor },
      rightPriceScale:{ borderColor: t.borderColor },
    });
    this.renderLines();
    this.drawHandles();
  }

  // ==================== INIT CHART - FIXED ====================
  private handleResize = (): void => {
    if (this.chart && this.chartContainer) {
      this.chart.applyOptions({ width: this.chartContainer.nativeElement.clientWidth });
      this.updateCanvasSize();
    }
  };

// ==================== INIT CHART - COMPLETE FIX ====================
private async initChart(): Promise<void> {
    const container = this.chartContainer.nativeElement;
    if (container.clientWidth === 0) { console.error('Chart container zero width'); return; }

    const t = this.themes[this.currentTheme];

 this.chart = LightweightCharts.createChart(container, {

  width: container.clientWidth,

  height: 600,

  layout: {
    background: {
      color: t.background,
    },

    textColor: t.textColor,

    fontFamily: 'Arial',

    fontSize: 12,
  },

  grid: {

    vertLines: {
      color: t.gridColor,
      style: 1,
    },

    horzLines: {
      color: t.gridColor,
      style: 1,
    },
  },

  // ================= TIME SCALE =================
  timeScale: {

    timeVisible: true,

    secondsVisible: false,

    borderVisible: true,

    borderColor: t.borderColor,

    fixLeftEdge: false,

    fixRightEdge: false,

    rightOffset: 5,

    tickMarkFormatter: (
      time: any,
      tickMarkType: any,
      locale: any
    ) => {

      const date = new Date(time * 1000);

      const year = date.getFullYear();

      const month = String(
        date.getMonth() + 1
      ).padStart(2, '0');

      const day = String(
        date.getDate()
      ).padStart(2, '0');

      return `${year}-${month}-${day}`;
    },
  },

  // ================= RIGHT SCALE =================
  rightPriceScale: {

    visible: true,

    autoScale: true,

    borderVisible: true,

    borderColor: t.borderColor,

    scaleMargins: {

      top: 0.1,

      bottom: 0.1,
    },
  },

  // ================= LEFT SCALE =================
  leftPriceScale: {

    visible: false,
  },

  // ================= CROSSHAIR =================
  crosshair: {

    mode: 1,

    vertLine: {

      color: '#758696',

      width: 1,

      style: 2,

      visible: true,

      labelVisible: true,
    },

    horzLine: {

      color: '#758696',

      width: 1,

      style: 2,

      visible: true,

      labelVisible: true,
    },
  },

  // ================= SCROLL =================
  handleScroll: {

    vertTouchDrag: true,

    horzTouchDrag: true,

    mouseWheel: true,

    pressedMouseMove: true,
  },

  // ================= SCALE =================
  handleScale: {

    axisPressedMouseMove: true,

    mouseWheel: true,

    pinch: true,
  },
});

    // ✅ Create candlestick series with explicit price scale assignment
    this.candlestickSeries = this.chart.addCandlestickSeries({
      upColor:       '#26a69a',
      downColor:     '#ef5350',
      borderVisible: false,
      wickUpColor:   '#26a69a',
      wickDownColor: '#ef5350',
      priceFormat:   { 
        type: 'price', 
        precision: 2, 
        minMove: 0.01 
      },
      priceScaleId: 'right',  // ✅ Explicitly assign to right scale
      priceLineVisible: false,
      lastValueVisible: true,
    });

    // ✅ CRITICAL: Force price scale to be visible
    this.chart.priceScale('right').applyOptions({
      visible: true,
      autoScale: true,
      mode: 0,  // Normal mode
    });

    // ✅ CRITICAL: Force time scale to be visible
    this.chart.timeScale().applyOptions({
      visible: true,
      timeVisible: true,
      secondsVisible: false,
    });

    // ✅ Fit content to make sure everything is visible
    this.chart.timeScale().fitContent();

    // Subscribe to chart events
    this.chart.subscribeClick((param: any) => {
      if (!param?.point) return;

      if (this.clickTimeout) {
        clearTimeout(this.clickTimeout);
        this.clickTimeout  = null;
        this.isDoubleClick = true;
        return;
      }

      this.isDoubleClick = false;
      this.clickTimeout  = setTimeout(() => {
        this.clickTimeout = null;
        if (this.isDoubleClick) { this.isDoubleClick = false; return; }

        if (this.activeTool === 'select') {
          if (this.dragDistance <= 5) this.handleSelectClick(param);
          this.dragDistance = 0;
        } else {
          this.handleChartClick(param);
        }
      }, 200);
    });

    this.chart.subscribeCrosshairMove((param: any) => {
      if (!param?.point) return;
      if (this.isDrawing && this.hasFirstPoint && this.previewSeries) {
        this.updatePreviewLine(param);
      }
    });

    // ✅ Subscribe to visible range changes to keep axes visible
    this.chart.timeScale().subscribeVisibleTimeRangeChange(() => {
      // Ensure axes remain visible after zoom/scroll
      this.chart.priceScale('right').applyOptions({
        visible: true,
      });
      this.chart.timeScale().applyOptions({
        visible: true,
      });
    });

    window.addEventListener('resize', this.handleResize);

    await this.loadChartData();

    setTimeout(() => this.setupHandleCanvas(), 100);
  }

  // ==================== HANDLE CANVAS ====================
  private setupHandleCanvas(): void {
    const canvas    = this.handleCanvas?.nativeElement;
    const container = this.chartContainer?.nativeElement;
    if (!canvas || !container) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width  = container.clientWidth  * dpr;
    canvas.height = container.clientHeight * dpr;
    canvas.style.width  = container.clientWidth  + 'px';
    canvas.style.height = container.clientHeight + 'px';
    canvas.style.position     = 'absolute';
    canvas.style.top          = '0';
    canvas.style.left         = '0';
    canvas.style.pointerEvents = 'none';

    this.handleCanvasContext = canvas.getContext('2d');
    this.handleCanvasContext?.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.startHandleRendering();
  }

  private startHandleRendering(): void {
    const draw = () => { this.drawHandles(); this.animationFrameId = requestAnimationFrame(draw); };
    this.animationFrameId = requestAnimationFrame(draw);
  }

  private drawHandles(): void {
    if (!this.handleCanvasContext || !this.selectedLineId) { this.clearHandles(); return; }

    const line = this.userLines.find(l => l.id === this.selectedLineId)
              ?? this.adminLines.find(l => l.id === this.selectedLineId);
    if (!line) { this.clearHandles(); return; }

    const sp = this.chartToScreenPoint(line.startTime, line.startPrice);
    const ep = this.chartToScreenPoint(line.endTime,   line.endPrice);
    if (!sp || !ep) { this.clearHandles(); return; }

    this.clearHandles();
    this.drawHandle(sp.x, sp.y, 'left');
    this.drawHandle(ep.x, ep.y, 'right');
  }

  private drawHandle(x: number, y: number, type: string): void {
    if (!this.handleCanvasContext) return;
    const ctx      = this.handleCanvasContext;
    const isActive = (this.isExtendingLeftHandle && type === 'left') ||
                     (this.isExtendingRightHandle && type === 'right');
    const radius   = isActive ? 8 : 6;
    ctx.save();
    ctx.beginPath(); ctx.arc(x, y, radius + 2, 0, Math.PI * 2);
    ctx.fillStyle = isActive ? 'rgba(255,165,0,0.3)' : 'rgba(255,165,0,0.15)'; ctx.fill();
    ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fillStyle = isActive ? '#FFA500' : '#FF8C00'; ctx.fill();
    ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.restore();
  }

  private clearHandles(): void {
    if (!this.handleCanvasContext || !this.handleCanvas?.nativeElement) return;
    const c = this.handleCanvas.nativeElement;
    this.handleCanvasContext.clearRect(0, 0, c.width, c.height);
  }

  private updateCanvasSize(): void {
    const canvas    = this.handleCanvas?.nativeElement;
    const container = this.chartContainer?.nativeElement;
    if (!canvas || !container) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width  = container.clientWidth  * dpr;
    canvas.height = container.clientHeight * dpr;
    canvas.style.width  = container.clientWidth  + 'px';
    canvas.style.height = container.clientHeight + 'px';
    this.handleCanvasContext?.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.drawHandles();
  }

  private getHandleAtPoint(sp: ScreenPoint): { type: 'left' | 'right'; lineId: string } | null {
    if (!this.selectedLineId) return null;
    const line = this.userLines.find(l => l.id === this.selectedLineId)
              ?? this.adminLines.find(l => l.id === this.selectedLineId);
    if (!line) return null;
    const s = this.chartToScreenPoint(line.startTime, line.startPrice);
    const e = this.chartToScreenPoint(line.endTime,   line.endPrice);
    if (!s || !e) return null;
    if (Math.hypot(sp.x - s.x, sp.y - s.y) < 15) return { type: 'left',  lineId: line.id };
    if (Math.hypot(sp.x - e.x, sp.y - e.y) < 15) return { type: 'right', lineId: line.id };
    return null;
  }

  // ==================== TOOL SELECTION ====================
  setActiveTool(tool: ToolMode): void {
    this.cancelDrawing();
    this.activeTool = tool;
    if (tool !== 'select') { this.selectedLineId = null; this.selectedLineOwner = null; this.clearHandles(); }
    this.showMessage(`Tool: ${tool}`, 'info');
    this.renderLines();
  }

  // ==================== DRAWING ====================
  private cancelDrawing(): void {
    this.isDrawing        = false;
    this.hasFirstPoint    = false;
    this.drawingStartPoint = null;
    if (this.previewSeries) {
      try { this.chart.removeSeries(this.previewSeries); } catch {}
      this.previewSeries = null;
    }
  }

  private handleChartClick(param: any): void {
    const sp: ScreenPoint = { x: param.point.x, y: param.point.y };
    const cp = this.screenToChartPoint(sp);
    if (!cp) return;

    if (this.activeTool === 'straightline') { this.finishDrawing(cp); return; }

    if (!this.isDrawing) {
      this.isDrawing        = true;
      this.drawingStartPoint = cp;
      this.previewSeries    = this.chart.addLineSeries({
        color: '#FFD700', lineWidth: 2, lineStyle: 2,
        priceLineVisible: false, lastValueVisible: false,
      });
      this.hasFirstPoint = true;
    } else {
      let endPoint = cp;
      if (this.shiftHeld) endPoint = this.snapToAngle(this.drawingStartPoint!, cp);
      this.finishDrawing(endPoint);
      this.cancelDrawing();
    }
  }

  private finishDrawing(endPoint: Point): void {
    let start: Point, end: Point;

    if (this.activeTool === 'straightline') {
      const tr = this.chart.timeScale().getVisibleRange();
      if (!tr) return;
      start = { x: 0, y: 0, time: tr.from as number, price: endPoint.price };
      end   = { x: 0, y: 0, time: tr.to   as number, price: endPoint.price };
    } else {
      if (!this.drawingStartPoint) return;
      start = { ...this.drawingStartPoint };
      end   = { ...endPoint };
      if (this.activeTool === 'hline') end.price = start.price;
      if (start.time > end.time) [start, end] = [end, start];
    }

    const newLine: DrawingLine = {
      id:         uuidv4(),
      testId:     this.testId,
      type:       this.userRole === 'admin' ? 'admin' : 'user',
      tool:       this.activeTool === 'straightline' ? 'hline' : this.activeTool as any,
      startX:     start.x, startY: start.y,
      endX:       end.x,   endY:   end.y,
      startTime:  start.time, startPrice: start.price,
      endTime:    end.time,   endPrice:   end.price,
      color:      '#FFD700',
      createdAt:  new Date(),
    };

    if (this.userRole === 'admin') {
      this.adminLines.push(newLine);
      this.drawingService.addAdminLine(this.testId, newLine).subscribe();
      this.renderLines();
      this.showMessage('✓ Admin line drawn.', 'success');
    } else {
      this.validateAndSaveUserLine(newLine);
    }
  }

  private updatePreviewLine(param: any): void {
    if (this.updatingPreview || !this.isDrawing || !this.previewSeries) return;
    this.updatingPreview = true;
    try {
      const sp: ScreenPoint = { x: param.point.x, y: param.point.y };
      let cp  = this.screenToChartPoint(sp);
      if (!cp) return;
      let end = { ...cp };
      if (this.activeTool === 'hline') end.price = this.drawingStartPoint!.price;
      const t1 = this.drawingStartPoint!.time, t2 = end.time;
      if (t1 === t2) return;
      const ordered = t1 < t2
        ? [{ time: t1, value: this.drawingStartPoint!.price }, { time: t2, value: end.price }]
        : [{ time: t2, value: end.price }, { time: t1, value: this.drawingStartPoint!.price }];
      this.previewSeries.setData(ordered);
    } catch (err) { console.warn('Preview update error', err); }
    finally { this.updatingPreview = false; }
  }

  private snapToAngle(start: Point, end: Point): Point { return end; }

  // ==================== SELECT & HIT TEST ====================
  private handleSelectClick(param: any): void {
    const sp: ScreenPoint = { x: param.point.x, y: param.point.y };
    const hit = this.getLineAtPoint(sp);
    if (hit) {
      this.selectedLineId    = hit.id;
      this.selectedLineOwner = hit.owner;
      this.renderLines();
      this.showMessage(`Line selected: ${hit.id.substring(0, 8)}…`, 'success');
    } 
    else {
      this.selectedLineId    = null;
      this.selectedLineOwner = null;
      this.renderLines();
      this.clearHandles();
      this.showMessage('Selection cleared', 'info');
    }
  }

  private getLineAtPoint(sp: ScreenPoint): { id: string; owner: 'user' | 'admin' } | null {
    for (const line of this.userLines) {
      const a = this.chartToScreenPoint(line.startTime, line.startPrice);
      const b = this.chartToScreenPoint(line.endTime,   line.endPrice);
      if (a && b && this.distanceToSegment(sp, a, b) < 10) return { id: line.id, owner: 'user' };
    }
    if (this.userRole === 'admin') {
      for (const line of this.adminLines) {
        const a = this.chartToScreenPoint(line.startTime, line.startPrice);
        const b = this.chartToScreenPoint(line.endTime,   line.endPrice);
        if (a && b && this.distanceToSegment(sp, a, b) < 10) return { id: line.id, owner: 'admin' };
      }
    }
    return null;
  }

  private distanceToSegment(p: ScreenPoint, a: ScreenPoint, b: ScreenPoint): number {
    const abx = b.x - a.x, aby = b.y - a.y;
    const apx = p.x - a.x, apy = p.y - a.y;
    const lenSq = abx * abx + aby * aby;
    if (lenSq === 0) return Math.hypot(apx, apy);
    const t = Math.max(0, Math.min(1, (apx * abx + apy * aby) / lenSq));
    return Math.hypot(p.x - (a.x + t * abx), p.y - (a.y + t * aby));
  }

  // ==================== DUPLICATE - FIXED ====================
  // ==================== DUPLICATE LINE FIX ====================

duplicateSelectedLine(): void {

  if (!this.selectedLineId) {
    this.showMessage('Select a line first', 'info');
    return;
  }

  const original =
    this.selectedLineOwner === 'user'
      ? this.userLines.find(l => l.id === this.selectedLineId)
      : this.adminLines.find(l => l.id === this.selectedLineId);

  if (!original) return;

  // ===== SMALL OFFSET =====
  const visibleRange = this.chart.timeScale().getVisibleRange();

  let smallPriceOffset = 5;

  if (this.chartData.length) {

    const prices = this.chartData.flatMap((d: any) => [
      d.high,
      d.low
    ]);

    const max = Math.max(...prices);
    const min = Math.min(...prices);

    // VERY SMALL GAP
    smallPriceOffset = (max - min) * 0.01;
  }

  const duplicatedLine: DrawingLine = {
    ...original,

    id: uuidv4(),

    type: 'user',

    color: '#00FF00',

    // SAME TIME
    startTime: original.startTime,
    endTime: original.endTime,

    // SMALL PRICE SHIFT
    startPrice: original.startPrice - smallPriceOffset,
    endPrice: original.endPrice - smallPriceOffset,

    createdAt: new Date(),
  };

  this.userLines.push(duplicatedLine);

  this.selectedLineId = duplicatedLine.id;
  this.selectedLineOwner = 'user';

  this.renderLines();

  this.drawingService
    .saveUserLine(this.testId, duplicatedLine)
    .subscribe();

  this.showMessage('Line duplicated', 'success');
}

  duplicateAndExtendManually(): void {
    this.duplicateSelectedLine();
    setTimeout(() => { 
      if (this.selectedLineId) {
        this.showExtensionControls(); 
      }
    }, 300);
  }

  // ==================== DRAG & EXTEND HANDLERS ====================
@HostListener('document:mousedown', ['$event'])
onMouseDown(event: MouseEvent): void {

  this.dragDistance = 0;

  if (this.activeTool !== 'select') return;

  const container = this.chartContainer?.nativeElement;

  if (!container) return;

  const rect = container.getBoundingClientRect();

  if (
    event.clientX < rect.left ||
    event.clientX > rect.right ||
    event.clientY < rect.top ||
    event.clientY > rect.bottom
  ) {
    return;
  }

  const sp: ScreenPoint = {
    x: event.clientX - rect.left,
    y: event.clientY - rect.top,
  };

  // ================= HANDLE CHECK =================
  const handle = this.getHandleAtPoint(sp);

  if (handle) {

    event.preventDefault();

    // DISABLE CHART MOVE
    this.chart.applyOptions({
      handleScroll: {
        vertTouchDrag: false,
        horzTouchDrag: false,
        mouseWheel: false,
        pressedMouseMove: false,
      },

      handleScale: {
        axisPressedMouseMove: false,
        mouseWheel: false,
        pinch: false,
      },
    });

    this.extendingLineIdHandle = handle.lineId;

    const selected =
      this.userLines.find(l => l.id === handle.lineId) ??
      this.adminLines.find(l => l.id === handle.lineId);

    if (selected) {
      this.originalLineState = structuredClone(selected);
    }

    if (handle.type === 'left') {
      this.isExtendingLeftHandle = true;
    } else {
      this.isExtendingRightHandle = true;
    }

    return;
  }

  // ================= LINE HIT =================
  const hit = this.getLineAtPoint(sp);

  if (!hit) return;

  this.selectedLineId = hit.id;
  this.selectedLineOwner = hit.owner;

  this.draggedLineId = hit.id;

  // ================= DISABLE CHART SCROLL =================
  this.chart.applyOptions({
    handleScroll: {
      vertTouchDrag: false,
      horzTouchDrag: false,
      mouseWheel: false,
      pressedMouseMove: false,
    },

    handleScale: {
      axisPressedMouseMove: false,
      mouseWheel: false,
      pinch: false,
    },
  });

  this.isDraggingLine = true;

  const selectedLine =
    hit.owner === 'user'
      ? this.userLines.find(l => l.id === hit.id)
      : this.adminLines.find(l => l.id === hit.id);

  if (!selectedLine) return;

  this.dragLineSnapshot = structuredClone(selectedLine);

  const chartPoint = this.screenToChartPoint(sp);

  if (!chartPoint) return;

  this.dragStartPoint = {
    time: chartPoint.time,
    price: chartPoint.price,
  };

  this.renderLines();
}

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    this.shiftHeld = event.shiftKey;
    if (this.isDraggingLine && this.draggedLineId) { this.handleLineDrag(event); return; }
    if ((this.isExtendingLeftHandle || this.isExtendingRightHandle) && this.extendingLineIdHandle) {
      this.handleLineExtension(event); return;
    }
  }

private handleLineDrag(
  event: MouseEvent
): void {

  const container =
    this.chartContainer?.nativeElement;

  if (!container) return;

  const rect =
    container.getBoundingClientRect();

  const sp: ScreenPoint = {

    x: event.clientX - rect.left,

    y: event.clientY - rect.top,
  };

  const currentPoint =
    this.screenToChartPoint(sp);

  if (
    !currentPoint ||
    !this.dragStartPoint ||
    !this.dragLineSnapshot
  ) {
    return;
  }

  const deltaTime =
    currentPoint.time -
    this.dragStartPoint.time;

  const deltaPrice =
    currentPoint.price -
    this.dragStartPoint.price;

  let targetLine:
    DrawingLine | undefined;

  if (
    this.selectedLineOwner === 'user'
  ) {

    targetLine =
      this.userLines.find(
        l => l.id === this.draggedLineId
      );

  } else {

    targetLine =
      this.adminLines.find(
        l => l.id === this.draggedLineId
      );
  }

  if (!targetLine) return;

  // ================= MOVE LINE =================
  targetLine.startTime = Math.round(
    this.dragLineSnapshot.startTime +
    deltaTime
  );

  targetLine.endTime = Math.round(
    this.dragLineSnapshot.endTime +
    deltaTime
  );

  targetLine.startPrice =
    this.dragLineSnapshot.startPrice +
    deltaPrice;

  targetLine.endPrice =
    this.dragLineSnapshot.endPrice +
    deltaPrice;

  this.renderSingleLine(targetLine);
}

private renderSingleLine(
  line: DrawingLine
): void {

  if (!this.chart) return;

  try {

    const isSelected =
      this.selectedLineId === line.id;

    const color =
      isSelected
        ? '#FFA500'
        : line.color || '#FFD700';

    const width =
      isSelected ? 3 : 2;

    let data: any[] = [];

    // ================= HORIZONTAL =================
    if (
      line.tool === 'hline' &&
      !this.isDraggingLine
    ) {

      const range =
        this.chart.timeScale().getVisibleRange();

      if (!range) return;

      data = [
        {
          time: range.from,
          value: line.startPrice,
        },
        {
          time: range.to,
          value: line.startPrice,
        },
      ];

    } else {

      // ================= NORMAL =================
      data = [
        {
          time: line.startTime,
          value: line.startPrice,
        },
        {
          time: line.endTime,
          value: line.endPrice,
        },
      ];
    }

    // ================= UPDATE EXISTING =================
    const existingSeries =
      this.lineSeriesMap.get(line.id);

    if (existingSeries) {

      existingSeries.applyOptions({

        color: color,

        lineWidth: width,
      });

      existingSeries.setData(data);

      return;
    }

    // ================= CREATE SERIES =================
    const series =
      this.chart.addLineSeries({

        color: color,

        lineWidth: width,

        priceLineVisible: false,

        lastValueVisible: false,

        crosshairMarkerVisible: false,

        lineStyle: 0,

        priceScaleId: 'right',
      });

    series.setData(data);

    this.lineSeriesMap.set(
      line.id,
      series
    );

  } catch (err) {

    console.error(
      'renderSingleLine error',
      err
    );
  }
}

 private handleLineExtension(event: MouseEvent): void {

  const container = this.chartContainer?.nativeElement;

  if (!container) return;

  const rect = container.getBoundingClientRect();

  const sp: ScreenPoint = {
    x: event.clientX - rect.left,
    y: event.clientY - rect.top,
  };

  const cp = this.screenToChartPoint(sp);

  if (!cp) return;

  const line =
    this.userLines.find(
      l => l.id === this.extendingLineIdHandle
    ) ??
    this.adminLines.find(
      l => l.id === this.extendingLineIdHandle
    );

  if (!line) return;

  if (this.isExtendingLeftHandle) {

    line.startTime = cp.time;
    line.startPrice = cp.price;

  } else if (this.isExtendingRightHandle) {

    line.endTime = cp.time;
    line.endPrice = cp.price;
  }

  this.renderSingleLine(line);
}

@HostListener('document:mouseup')
onMouseUp(): void {

  // ENABLE AGAIN
  this.chart.applyOptions({

    handleScroll: {

      vertTouchDrag: true,

      horzTouchDrag: true,

      mouseWheel: true,

      pressedMouseMove: true,
    },

    handleScale: {

      axisPressedMouseMove: true,

      mouseWheel: true,

      pinch: true,
    },
  });

  if (
    this.isDraggingLine &&
    this.draggedLineId
  ) {

    this.saveDraggedLine();
  }

  if (
    (
      this.isExtendingLeftHandle ||
      this.isExtendingRightHandle
    ) &&
    this.extendingLineIdHandle
  ) {

    this.saveExtendedLine();
  }

  this.isExtendingLeftHandle = false;

  this.isExtendingRightHandle = false;

  this.extendingLineIdHandle = null;

  this.isDraggingLine = false;

  this.draggedLineId = null;

  this.dragLineSnapshot = null;

  this.dragStartPoint = null;

  this.dragDistance = 0;

  this.renderLines();
}

  private saveDraggedLine(): void {
    if (this.selectedLineOwner === 'user') {
      const line = this.userLines.find(l => l.id === this.draggedLineId);
      if (line) this.drawingService.updateUserLine(this.testId, line.id, line).subscribe({
        next:  () => this.showMessage('Line position saved', 'success'),
        error: (e) => console.error('Save failed', e),
      });
    }
  }

  private saveExtendedLine(): void {
    if (this.selectedLineOwner === 'user') {
      const line = this.userLines.find(l => l.id === this.extendingLineIdHandle);
      if (line) this.drawingService.updateUserLine(this.testId, line.id, line).subscribe({
        next:  () => this.showMessage('Line extended successfully', 'success'),
        error: (e) => console.error('Save failed', e),
      });
    }
  }

  // ==================== LINE RENDERING - FIXED ====================
  private removeSeries(id: string): void {
    if (this.lineSeriesMap.has(id)) {
      try { 
        const series = this.lineSeriesMap.get(id);
        if (series) {
          this.chart.removeSeries(series);
        }
      } catch (e) {
        console.warn('Error removing series:', e);
      }
      this.lineSeriesMap.delete(id);
    }
  }

  private renderLine(line: DrawingLine): void {
    if (!this.chart) return;
    try {
      const tr = this.chart.timeScale().getVisibleRange();
      if (!tr) return;
      const from = tr.from as number;
      const to = tr.to as number;
      
      this.removeSeries(line.id);

      const isSelected = this.selectedLineId === line.id;
      const color = isSelected ? '#FFA500' : (line.color || (line.type === 'admin' ? '#FFFF00' : '#FFD700'));
      const width = isSelected ? 3 : 2;

      let data: any[];
      if (line.tool === 'hline') {
        data = [
          { time: from, value: line.startPrice },
          { time: to, value: line.startPrice }
        ];
      } else {
        data = [
          { time: line.startTime, value: line.startPrice },
          { time: line.endTime, value: line.endPrice },
        ];
      }

      const series = this.chart.addLineSeries({
        color: color,
        lineWidth: width,
        priceLineVisible: false,
        lastValueVisible: false,
        crosshairMarkerVisible: false,
        lineStyle: 0,
      });
      
      series.setData(data);
      this.lineSeriesMap.set(line.id, series);
      
    } catch (e) { 
      console.error('renderLine error:', e, line); 
    }
  }

private renderLines(): void {

  if (!this.chart) return;

  // REMOVE OLD SERIES
  this.lineSeriesMap.forEach((series) => {

    try {

      this.chart.removeSeries(series);

    } catch {}

  });

  this.lineSeriesMap.clear();

  // USER LINES
  this.userLines.forEach(line => {

    this.renderSingleLine(line);

  });

  // ADMIN LINES
  if (this.userRole === 'admin') {

    this.adminLines.forEach(line => {

      this.renderSingleLine(line);

    });
  }

  // IMPORTANT
  this.chart.priceScale('right').applyOptions({
    visible: true,
    autoScale: true,
  });

  this.chart.timeScale().applyOptions({
    visible: true,
  });
}

  // ==================== VALIDATION ====================
  private validateAndSaveUserLine(line: DrawingLine): void {
    this.userLines.push(line);
    this.drawingService.saveUserLine(this.testId, line).subscribe({
      next:  () => { this.renderLines(); this.showMessage('✓ Line drawn!', 'success'); },
      error: (e) => console.error('Save failed', e),
    });
  }

  // ==================== LINE MANAGEMENT ====================
  deleteSelectedLine(): void {
    if (!this.selectedLineId) { this.showMessage('Select a line first.', 'info'); return; }
    const lineId = this.selectedLineId, owner = this.selectedLineOwner;
    this.selectedLineId = null; this.selectedLineOwner = null; this.clearHandles();

    if (owner === 'user') {
      this.drawingService.deleteUserLine(this.testId, lineId).subscribe({
        next:  (updated) => { 
          this.userLines = updated || []; 
          this.renderLines(); 
          this.showMessage('✓ Line deleted!', 'success'); 
        },
        error: () => this.showMessage('Delete failed.', 'error'),
      });
    }
  }

  resetAllLines(): void {
    if (!confirm('Reset ALL lines? This cannot be undone.')) return;
    this.userLines = []; this.adminLines = [];
    this.selectedLineId = null; this.selectedLineOwner = null;
    this.clearHandles(); this.renderLines();
    if (this.userRole === 'admin') {
      this.drawingService.clearAllUserLines(this.testId).subscribe();
      this.drawingService.clearAdminLines(this.testId).subscribe();
    } else {
      this.drawingService.clearAllUserLines(this.testId).subscribe();
    }
    this.showMessage('All lines cleared', 'success');
  }

  saveAllLines(): void {
    if (this.userRole !== 'admin') { this.showMessage('Only admin can save lines.', 'error'); return; }
    this.drawingService.saveAdminLines(this.testId, this.adminLines).subscribe({
      next:  () => this.showMessage('✓ Admin lines saved!', 'success'),
      error: () => this.showMessage('Save failed.', 'error'),
    });
  }

  // ==================== EXTENSION CONTROLS ====================
  showExtensionControls(): void {
    if (!this.selectedLineId) { this.showMessage('Select a line first to extend.', 'info'); return; }
    this.extendingLineId  = this.selectedLineId;
    this.showExtendControls = true;
    this.extendLeftValue  = 0;
    this.extendRightValue = 0;
  }

  closeExtendControls(): void { this.showExtendControls = false; this.extendingLineId = null; }

  extendLineManually(): void {
    if (!this.extendingLineId) return;
    const line = this.userLines.find(l => l.id === this.extendingLineId);
    if (!line) return;

    const dt = line.endTime - line.startTime, dp = line.endPrice - line.startPrice;
    const slope = dt !== 0 ? dp / dt : 0;
    const intercept = line.startPrice - slope * line.startTime;
    const leftExt   = this.extendLeftValue  * 86400;
    const rightExt  = this.extendRightValue * 86400;

    const updated: DrawingLine = {
      ...line,
      startTime:  line.startTime - leftExt,
      startPrice: slope * (line.startTime - leftExt) + intercept,
      endTime:    line.endTime   + rightExt,
      endPrice:   slope * (line.endTime   + rightExt) + intercept,
    };

    const idx = this.userLines.findIndex(l => l.id === line.id);
    if (idx !== -1) { this.userLines[idx] = updated; this.renderLines(); }

    this.drawingService.updateUserLine(this.testId, line.id, updated).subscribe({
      next:  () => { this.showMessage('✓ Line extended!', 'success'); this.closeExtendControls(); },
      error: (e) => console.error('Extension failed:', e),
    });
  }

  // ==================== COORDINATE CONVERSION ====================
  private screenToChartPoint(sp: ScreenPoint): Point | null {
    try {
      const time  = this.chart.timeScale().coordinateToTime(sp.x) as number | null;
      const price = this.candlestickSeries.coordinateToPrice(sp.y) as number | null;
      if (time == null || price == null) return null;
      return { x: sp.x, y: sp.y, time, price };
    } catch { return null; }
  }

  private chartToScreenPoint(time: number, price: number): ScreenPoint | null {
    try {
      const x = this.chart.timeScale().timeToCoordinate(time) as number | null;
      const y = this.candlestickSeries.priceToCoordinate(price) as number | null;
      if (x == null || y == null) return null;
      return { x, y };
    } catch { return null; }
  }

  // ==================== DATA ====================
  private async loadData(): Promise<void> {
    this.drawingService.getUserLines(this.testId).subscribe(lines => {
      this.userLines = lines || [];
      this.renderLines();
    });
    if (this.userRole === 'admin') {
      this.drawingService.getAdminLines(this.testId).subscribe(lines => {
        this.adminLines = lines || [];
        this.renderLines();
      });
    }
  }

  private async loadChartData(): Promise<void> {
    try {
      this.testService.getTestById(this.testId).subscribe({
        next: (test) => {
          const raw = test?.data ?? test?.chartData;
          if (Array.isArray(raw) && raw.length > 0) {
            this.chartData = this.normalizeChartData(raw);
          } else {
            console.warn('[Chart] No data from API, using mock data');
            this.chartData = this.generateMockData();
          }
          this.applyChartData();
        },
        error: (err) => {
          console.error('[Chart] API error, using mock data', err);
          this.chartData = this.generateMockData();
          this.applyChartData();
        },
      });
    } catch (e) {
      console.error('[Chart] Unexpected error', e);
      this.chartData = this.generateMockData();
      this.applyChartData();
    }
  }

  private normalizeChartData(data: any[]): any[] {
    if (!data?.length) return [];

    const sample = data[0];

    const dateKey = Object.keys(sample).find(k =>
      ['date','time','datetime','timestamp','day'].includes(k.toLowerCase().trim())
    ) ?? Object.keys(sample)[0];

    const findKey = (...cands: string[]) =>
      Object.keys(sample).find(k => cands.includes(k.toLowerCase().trim()));

    const openKey  = findKey('open','o');
    const highKey  = findKey('high','h');
    const lowKey   = findKey('low','l');
    const closeKey = findKey('close','c','price','value','last');

    const toUnix = (raw: any): number => {
      if (typeof raw === 'number') {
        return raw > 100000 ? raw : Math.floor(raw * 86400);
      }
      if (typeof raw === 'string') {
        const dmy = raw.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
        if (dmy) {
          const d = new Date(`${dmy[3]}-${dmy[2].padStart(2,'0')}-${dmy[1].padStart(2,'0')}`);
          if (!isNaN(d.getTime())) return Math.floor(d.getTime() / 1000);
        }
        const iso = new Date(raw);
        if (!isNaN(iso.getTime())) return Math.floor(iso.getTime() / 1000);
      }
      return NaN;
    };

    const mapped = data.map(item => {
      const close = closeKey ? Number(item[closeKey]) : 0;
      return {
        time:  toUnix(item[dateKey]),
        open:  openKey ? Number(item[openKey])  : close,
        high:  highKey ? Number(item[highKey])  : close,
        low:   lowKey  ? Number(item[lowKey])   : close,
        close,
      };
    })
    .filter(d => !isNaN(d.time) && d.time > 0 && !isNaN(d.close) && d.close > 0)
    .sort((a, b) => a.time - b.time)
    .filter((d, i, arr) => i === 0 || d.time !== arr[i - 1].time);

    console.log(`[normalizeChartData] dateKey="${dateKey}" closeKey="${closeKey}" → ${mapped.length} rows`);
    return mapped;
  }

  private generateMockData(): any[] {
    const data: any[] = [];
    let base = 24000;
    const start = new Date();
    start.setMonth(start.getMonth() - 3);
    for (let i = 0; i < 90; i++) {
      const change = (Math.random() - 0.5) * 200;
      base = Math.max(22000, Math.min(26000, base + change));
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      if (d.getDay() === 0 || d.getDay() === 6) continue;
      const open  = base;
      const close = base + (Math.random() - 0.5) * 150;
      const high  = Math.max(open, close) + Math.random() * 80;
      const low   = Math.min(open, close) - Math.random() * 80;
      data.push({ time: Math.floor(d.getTime() / 1000), open, high, low, close });
    }
    return data;
  }

  private applyChartData(): void {
    if (!this.candlestickSeries || !this.chartData.length) return;
    try {
      this.candlestickSeries.setData(this.chartData);
      this.chart.timeScale().fitContent();
      this.renderLines();
    } catch (e) {
      console.error('[applyChartData] Error:', e);
    }
  }

  filterChartData(): void { this.applyChartData(); }
  onDurationChange(): void { this.applyChartData(); }

  backToDashboard(): void {
    this.router.navigate([this.userRole === 'admin' ? '/admin/dashboard' : '/user/dashboard']);
  }

  private showMessage(msg: string, type: 'success' | 'error' | 'info'): void {
    this.validationMessage = msg;
    this.messageType = type;
    setTimeout(() => { this.validationMessage = ''; }, 3000);
  }

  // ==================== KEYBOARD SHORTCUTS ====================
  @HostListener('document:keydown', ['$event'])
  onKeyDown(event: KeyboardEvent): void {
    const tag = (event.target as HTMLElement)?.tagName;
    if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;

    if (event.key === 'Delete' && this.activeTool === 'select' && this.selectedLineId) {
      event.preventDefault(); this.deleteSelectedLine(); return;
    }
    if (event.key === 'Escape') {
      if (this.isDrawing) this.cancelDrawing();
      this.setActiveTool('select');
      this.selectedLineId = null; this.clearHandles(); this.renderLines();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'd') {
      event.preventDefault();
      this.duplicateSelectedLine();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
      event.preventDefault(); if (this.userRole === 'admin') this.saveAllLines(); return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'r') {
      event.preventDefault(); this.resetAllLines(); return;
    }
    if (event.key === '1') this.setActiveTool('select');
    if (event.key === '2') this.setActiveTool('trendline');
    if (event.key === '3') this.setActiveTool('straightline');
  }
}